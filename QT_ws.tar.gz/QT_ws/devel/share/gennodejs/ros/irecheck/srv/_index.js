
"use strict";

let FieldsSrv = require('./FieldsSrv.js')

module.exports = {
  FieldsSrv: FieldsSrv,
};
