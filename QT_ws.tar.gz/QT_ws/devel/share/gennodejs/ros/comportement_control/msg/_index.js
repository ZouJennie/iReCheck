
"use strict";

let GestureCommand = require('./GestureCommand.js');

module.exports = {
  GestureCommand: GestureCommand,
};
